function getRandomInt(max) {
  return Math.floor(Math.random() * max);
}

console.log(getRandomInt(5));




const img1 = document.getElementById('img1');
const img2 = document.getElementById('img2');
const img3 = document.getElementById('img3');
const img4 = document.getElementById('img4');



function onDragStart(event) {
  event.dataTransfer.setData('text/plain', event.target.id);
  event.currentTarget.style.backgroundColor = 'yellow';
}

function onDragOver(event) {
  event.preventDefault(); 
}

function onDrop(event) {
  event.preventDefault();

  const id = event.dataTransfer.getData('text/plain');
  const draggedElement = document.getElementById(id);
  const target = event.currentTarget;

 
  if (target.id === "first-element") {
    target.innerHTML = `<img src="${draggedElement.src}" alt="${draggedElement.alt}">`;
  } else if (target.id === "second-element") {
    target.innerHTML = `<img src="${draggedElement.src}" alt="${draggedElement.alt}">`;
  } else if (target.id === "third-element") {
    target.innerHTML = `<img src="${draggedElement.src}" alt="${draggedElement.alt}">`;
  } else if (target.id === "fourth-element") {
    target.innerHTML = `<img src="${draggedElement.src}" alt="${draggedElement.alt}">`;
  }
  
  target.style.backgroundColor = ''; 
}
